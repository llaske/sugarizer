Made by Michaël Ohayon for the Google Summer of Code 2015

*Gear by Icomatic from the Noun Project
*play by Alex Fuller from the Noun Project
*hourglass by Sergey Demushkin from the Noun Project
*Minus by aguycalledgary from the Noun Project