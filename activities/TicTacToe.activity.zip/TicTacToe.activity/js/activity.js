define(["sugar-web/activity/activity", "sugar-web/env", "sugar-web/graphics/icon", "webL10n","sugar-web/graphics/presencepalette"], function (activity, env, icon, webL10n, presencepalette) {

	// Manipulate the DOM only when it is ready.
	requirejs(['domReady!'], function (doc) {

		// Initialize the activity.
		activity.setup();

		// Game Preparation
		var winners = new Array();
		var computer = true;
		var computerSequence = [0, 1, 2, 3, 4, 5, 6, 7, 8];
		var player1Selections = new Array();
		var player2Selections = new Array();
		var gameBoard = [null, null, null, null, null, null, null, null, null];
		var moves = 0;
		var currentPlayer = 0;
		var mainPlayer = 1;
		var numberOfPlayers = 0;
		var opponentID = 0;
		var size = 3;

		var currentenv;
		//Player and Computer icon
		env.getEnvironment(function(err, environment) {
			currentenv = environment;

			if(computer == true){
				document.getElementById("player-icon").style.visibility = "visible";
				document.getElementById("opponent-icon").style.visibility = "hidden";
			}

			// Set current language to Sugarizer
			var defaultLanguage = (typeof chrome != 'undefined' && chrome.app && chrome.app.runtime) ? chrome.i18n.getUILanguage() : navigator.language;
			var language = environment.user ? environment.user.language : defaultLanguage;
			webL10n.language.code = language;

			//Load saved data
			activity.getDatastoreObject().loadAsText(function(error, metadata, data) {
				if (error==null && data!=null) {
					gameBoard = JSON.parse(data);

					for (var q = 0; q < gameBoard.length; q++){

						if(gameBoard[q] == 1){
							playerTurn(document.getElementById(q));
						} else if (gameBoard[q] == 2){
							computerTurn(document.getElementById(q));
						}
						document.getElementById("player-icon").style.visibility = "visible";
						document.getElementById("opponent-icon").style.visibility = "hidden";
					}
					if(computer == true){
							announceWinner();
					} else{
						win_draw();
					}
				}
			});

			// Shared instances
			if (environment.sharedId) {
				console.log("Shared instance");
				presence = activity.getPresenceObject(function(error, network) {
					computer = false;
					mainPlayer = 2;
					opponentID = 1;
					network.onDataReceived(onNetworkDataReceived);
					network.onSharedActivityUserChanged(onNetworkUserChanged);
				});
			}

		});

		function drawBoard() {
	    var Parent = document.getElementById("mainBoard");
	    var counter = 0;

	    while (Parent.hasChildNodes()) {
	        Parent.removeChild(Parent.firstChild);
	    }

			//Process localize event
			window.addEventListener("localized", function(){
				document.getElementById("new-game-button").title = webL10n.get("NewGame");
				document.getElementById("stop-button").title = webL10n.get("Stop");
			})

			//Creates table row and table data
	    for (s = 0; s < 3; s++) {
	        var row = document.createElement("tr");

	        for (r = 0; r < 3; r++) {
	            var col = document.createElement("td");
	            col.id = counter;

	            var handler = function(e) {
								if (computer == true){
		              if (currentPlayer == 0 && gameBoard[this.id] == null) {
										playerTurn(this);

										setTimeout(function(){
											announceWinner();
											currentPlayer = 1;
										}, 1000)
										setTimeout(function(){
											var chosenBox = computerSequence[Math.floor(Math.random()*computerSequence.length)];
											var newColID = document.getElementById(chosenBox);

											if (currentPlayer = 1 && moves != 9){
												computerTurn(newColID);
												setTimeout(function(){
													announceWinner();
													currentPlayer = 0;
													document.getElementById("player-icon").style.visibility = "visible";
													document.getElementById("opponent-icon").style.visibility = "hidden";
												}, 1000)
											}
										}, 1000);
									}
								}
								else{
									if (mainPlayer == opponentID && gameBoard[this.id] == null){
										playerTurn(this);
										setTimeout(function(){
											win_draw();
										}, 1000)
										//After X, O's turn
										if(opponentID == 1){
											opponentID = 2;
										} else{
											opponentID = 1;
										}
										if (presence) {
											presence.sendMessage(presence.getSharedInfo().id, {
												user: presence.getUserInfo(),
												content: {
													action: 'nextTurn'
												},
												userColor: currentenv.user.colorvalue
											});
										}
									}
								}
	            };


							col.addEventListener('click', handler);


	            row.appendChild(col);
	            counter++;
	        }

	        Parent.appendChild(row);
	    }
	    winningPatterns();

		}

		//Computer Turn. Creates O icon and places it to the column according to the ComputerSequence.
		function computerTurn(column){
			document.getElementById("player-icon").style.visibility = "hidden";
			document.getElementById("opponent-icon").style.visibility = "visible";
			var o_icon = document.createElement("div");
			o_icon.className = "o_icon";

			if(column != null){
				moves +=1;
				column.appendChild(o_icon);
				icon.colorize(o_icon, currentenv.user.colorvalue);
				player2Selections.push(parseInt(column.id));
				player2Selections.sort(function(a, b) { return a - b });
				gameBoard[column.id] = 2;

				computerSequence.splice(computerSequence.indexOf(parseInt(column.id)), 1);
			}
			else
			{
				return;
			}

		}

		//Player's Turn. Creates X or O icon when column is pressed.
		function playerTurn(column) {
			if (mainPlayer == 1){
				moves +=1;
				create_X(column, currentenv.user.colorvalue);
				player1Selections.push(parseInt(column.id));
				player1Selections.sort(function(a, b) { return a - b });
				gameBoard[column.id] = 1;

				computerSequence.splice(computerSequence.indexOf(parseInt(column.id)), 1);
			}else if(mainPlayer == 2){
				moves +=1;
				create_O(column, currentenv.user.colorvalue);

				player2Selections.push(parseInt(column.id));
				player2Selections.sort(function(a, b) { return a - b });
				gameBoard[column.id] = 2;

				computerSequence.splice(computerSequence.indexOf(parseInt(column.id)), 1);
			}

			if (presence) {
				presence.sendMessage(presence.getSharedInfo().id, {
					user: presence.getUserInfo(),
					content: {
						action: 'update',
						data: column.id,
					},
					userColor: currentenv.user.colorvalue
				});
			}
		}

		//Create X icon
		function create_X(column, color){
			var x_icon = document.createElement("div");
			x_icon.className = "x_icon";

			column.appendChild(x_icon);

			icon.colorize(x_icon, color);
		}

		//Create O icon
		function create_O(column, color){
			var o_icon = document.createElement("div");
			o_icon.className = "o_icon";

			column.appendChild(o_icon);
			icon.colorize(o_icon, color);
		}

		//List of possible winning patterns
		function winningPatterns(){
		    winners.push([0, 1, 2]);
		    winners.push([3, 4, 5]);
		    winners.push([6, 7, 8]);
		    winners.push([0, 3, 6]);
		    winners.push([1, 4, 7]);
		    winners.push([2, 5, 8]);
		    winners.push([0, 4, 8]);
		    winners.push([2, 4, 6]);
		}

		//Detects if a pattern is made
		function checkWinner() {
				// check if current player has a winning hand
				// only start checking when player x has size number of selections
				var win = false;
				var playerSelections = new Array();

				if(computer == true){
					if (currentPlayer == 0)
						 playerSelections = player1Selections;
					else {
						playerSelections = player2Selections;
					}
				} else{
					if (mainPlayer == 1)
						 playerSelections = player1Selections;
					else {
						playerSelections = player2Selections;
					}
				}


				if (playerSelections.length >= size) {
						// check if any 'winners' are also in your selections

						for (i = 0; i < winners.length; i++) {
								var sets = winners[i];  // winning hand
								var setFound = true;

								for (r = 0; r < sets.length; r++) {
										// check if number is in current players hand
										// if not, break, not winner
										var found = false;

										// players hand
										for (s = 0; s < playerSelections.length; s++) {
												if (sets[r] == playerSelections[s]) {
														found = true;
														break;
												}
										}

										// value not found in players hand
										// not a valid set, move on
										if (found == false) {
												setFound = false;
												break;
										}
								}

								if (setFound == true) {
										win = true;
										break;
								}
						}
				}

				return win;
		}

		//Announces Winner or Draw (computer mode)
		function announceWinner(){
			var isWin = checkWinner();

			//Winners are identified when XXX or OOO pattern is made
			//If no pattern is made at the end of the game, it results to a tie.
			if (isWin)
			{
				if(currentPlayer == 0){
					document.getElementById("mainBoard").style.display = "none";
					document.getElementById("player-icon").style.display = "none";
					document.getElementById("opponent-icon").style.display = "none";
					document.getElementById("announceWin").innerHTML = "<h1>"+webL10n.get("Win", {name:currentenv.user.name})+ "</h1>";
				}
				else if (currentPlayer == 1){
					document.getElementById("mainBoard").style.display = "none";
					document.getElementById("player-icon").style.display = "none";
					document.getElementById("opponent-icon").style.display = "none";
					document.getElementById("announceWin").innerHTML = "<h1>"+webL10n.get("Win", {name:"Computer"})+ "</h1>";
				}
			}

			else if(moves == 9)
			{
				document.getElementById("mainBoard").style.display = "none";
				document.getElementById("player-icon").style.display = "none";
				document.getElementById("opponent-icon").style.display = "none";
				document.getElementById("announceWin").innerHTML = "<h1>"+webL10n.get("Draw") + "</h1>";
			}
		}

		//Announces Winner or Draw (Multiplayer mode)
		function win_draw(){

			var isWin = checkWinner();

			if (isWin)
			{
				document.getElementById("mainBoard").style.display = "none";
				document.getElementById("player-icon").style.display = "none";
				document.getElementById("opponent-icon").style.display = "none";
				document.getElementById("announceWin").innerHTML = "<h1>"+webL10n.get("Win", {name:currentenv.user.name})+ "</h1>";
				if (presence) {
					presence.sendMessage(presence.getSharedInfo().id, {
						user: presence.getUserInfo(),
						content: {
							action: 'win',
							data: currentenv.user.name
						}
					});
				}
			} else if(moves == 5)
			{
				document.getElementById("mainBoard").style.display = "none";
				document.getElementById("player-icon").style.display = "none";
				document.getElementById("opponent-icon").style.display = "none";
				document.getElementById("announceWin").innerHTML = "<h1>"+webL10n.get("Draw") + "</h1>";
				if (presence) {
					presence.sendMessage(presence.getSharedInfo().id, {
						user: presence.getUserInfo(),
						content: {
							action: 'draw'
						}
					});
				}
			}

		}


		//Save Tic Tac Toe to Journal
		function gotoDatastore() {
			console.log("writing...");
			var jsonData = JSON.stringify(gameBoard);
			activity.getDatastoreObject().setDataAsText(jsonData);
			activity.getDatastoreObject().save(function (error) {
				if (error === null) {
					console.log("write done.");
					console.log(gameBoard);
				} else {
					console.log("write failed.");
				}
			});
		}
		document.getElementById("stop-button").addEventListener('click', function (event) {
			gotoDatastore();
		});

		//New Game
		document.getElementById("new-game-button").addEventListener('click', function(event){
			gameBoard = [null, null, null, null, null, null, null, null, null];
			gotoDatastore();
			window.location.reload();
		});

		// Link presence palette
		var presence = null;
		var palette = new presencepalette.PresencePalette(document.getElementById("network-button"), undefined);
		//Shared Listener
		var isHost = false;
		palette.addEventListener('shared', function() {
			palette.popDown();
			console.log("Want to share");
			presence = activity.getPresenceObject(function(error, network) {
				if (error) {
					console.log("Sharing error");
					return;
				}
				network.createSharedActivity('org.sugarlabs.TicTacToe', function(groupId) {
					console.log("Activity shared");
					isHost = true;
					computer = false;
					opponentID = 1;
				});
				network.onDataReceived(onNetworkDataReceived);
				network.onSharedActivityUserChanged(onNetworkUserChanged);
			});
		});

		var onNetworkDataReceived = function(msg) {
			if (presence.getUserInfo().networkId === msg.user.networkId) {
				return;
			}
			switch (msg.content.action) {
				case 'init':
					gameBoard = msg.content.data;
					console.log(gameBoard);
					for(var c = 0; c < gameBoard.length; c++){
						if (gameBoard[c] == 1){
							opponentID = 1;
							create_X(document.getElementById(c), msg.content.userColor);

						} else if(gameBoard[c] == 2){
							opponentID = 2;
							create_O(document.getElementById(c), msg.content.userColor);
						}
					}
					if (mainPlayer == 1){
						opponentID = 1;
						gameBoard[msg.content.data] = 2;
						create_O(document.getElementById(msg.content.data), currentenv.user.colorvalue);
					} else if(mainPlayer == 2){
						opponentID = 2;
						gameBoard[msg.content.data] = 1;
						create_X(document.getElementById(msg.content.data), msg.userColor);
					}
					break;
				case 'update':
					if (mainPlayer == 1){
						opponentID = 1;
						gameBoard[msg.content.data] = 2;
						create_O(document.getElementById(msg.content.data), msg.userColor);

					} else if(mainPlayer == 2){
							opponentID = 2;
							gameBoard[msg.content.data] = 1;
							create_X(document.getElementById(msg.content.data), msg.userColor);
					}
					break;
				case 'win':
					setTimeout(function(){
						document.getElementById("mainBoard").style.display = "none";
						document.getElementById("player-icon").style.display = "none";
						document.getElementById("opponent-icon").style.display = "none";
						document.getElementById("announceWin").innerHTML = "<h1>"+webL10n.get("Win", {name:msg.content.data})+ "</h1>";
					}, 1000)
					break;
				case 'draw':
					setTimeout(function(){
						document.getElementById("mainBoard").style.display = "none";
						document.getElementById("player-icon").style.display = "none";
						document.getElementById("opponent-icon").style.display = "none";
						document.getElementById("announceWin").innerHTML = "<h1>"+webL10n.get("Draw") + "</h1>";
					}, 1000)
					break;
				case 'exit':
					activity.close();
					console.log("Two Players only. Please wait.");
					break;
			}


		};

		var onNetworkUserChanged = function(msg) {
			console.log("User "+msg.user.name+" "+(msg.move == 1 ? "join": "leave"));
			if (isHost) {
				if (numberOfPlayers == 0) {
					presence.sendMessage(presence.getSharedInfo().id, {
						user: presence.getUserInfo(),
						content: {
							action: 'init',
							data: gameBoard,
							userColor: currentenv.user.colorvalue
						}
					});
					numberOfPlayers++;
				} else{
					console.log("Player exceed");
					presence.sendMessage(presence.getSharedInfo().id, {
						user: presence.getUserInfo(),
						content: {
							action: 'exit',
							data: msg.user.networkId
						}
					});
				}
			}
		};

		window.onload = drawBoard();

	});

});
