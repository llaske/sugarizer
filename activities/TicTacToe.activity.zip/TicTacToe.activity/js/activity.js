define(["sugar-web/activity/activity", "sugar-web/env", "sugar-web/graphics/icon", "webL10n"], function (activity, env, icon, webL10n) {

	// Manipulate the DOM only when it is ready.
	requirejs(['domReady!'], function (doc) {

		// Initialize the activity.
		activity.setup();

		// Game Preparation
		var winners = new Array();
		var computer = true;
		var computerSequence = [0, 1, 2, 3, 4, 5, 6, 7, 8];
		var player1Selections = new Array();
		var player2Selections = new Array();
		var gameBoard = [null, null, null, null, null, null, null, null, null];
		var moves = 0;
		var currentPlayer = 0;
		var size = 3;

		//Main Tic tac toe board and game
		var currentenv;
		function drawBoard() {
		    var Parent = document.getElementById("mainBoard");
		    var counter = 0;

		    while (Parent.hasChildNodes()) {
		        Parent.removeChild(Parent.firstChild);
		    }

				//Player and Computer icon
				env.getEnvironment(function(err, environment) {
					currentenv = environment;

					document.getElementById("player-icon").style.visibility = "visible";
					document.getElementById("computer-icon").style.visibility = "hidden";

					// Set current language to Sugarizer
					var defaultLanguage = (typeof chrome != 'undefined' && chrome.app && chrome.app.runtime) ? chrome.i18n.getUILanguage() : navigator.language;
					var language = environment.user ? environment.user.language : defaultLanguage;
					webL10n.language.code = language;

					//Load saved data
					activity.getDatastoreObject().loadAsText(function(error, metadata, data) {
						if (error==null && data!=null) {
							gameBoard = JSON.parse(data);

							for (var q = 0; q < gameBoard.length; q++){

								if(gameBoard[q] == 1){
									playerTurn(document.getElementById(q));
								} else if (gameBoard[q] == 2){
									computerTurn(document.getElementById(q));
								}
								document.getElementById("player-icon").style.visibility = "visible";
								document.getElementById("computer-icon").style.visibility = "hidden";
							}
							announceWinner();
						}
					});

				});

				//Process localize event
				window.addEventListener("localized", function(){
					document.getElementById("new-game-button").title = webL10n.get("NewGame");
					document.getElementById("stop-button").title = webL10n.get("Stop");
				})

				//Creates table row and table data
		    for (s = 0; s < 3; s++) {
		        var row = document.createElement("tr");

		        for (r = 0; r < 3; r++) {
		            var col = document.createElement("td");
		            col.id = counter;

		            var handler = function(e) {
		                if (currentPlayer == 0 && gameBoard[this.id] == null) {

											playerTurn(this);

											setTimeout(function(){
												announceWinner();
												currentPlayer = 1;
											}, 1000)
											setTimeout(function(){
												var chosenBox = computerSequence[Math.floor(Math.random()*computerSequence.length)];
												var newColID = document.getElementById(chosenBox);

												if (currentPlayer = 1 && moves != 9 && computer == true){
													computerTurn(newColID);
													setTimeout(function(){
														announceWinner();
														currentPlayer = 0;
														document.getElementById("player-icon").style.visibility = "visible";
														document.getElementById("computer-icon").style.visibility = "hidden";
													}, 1000)
												}
											}, 1000);
										}
		            };

								col.addEventListener('click', handler);

		            row.appendChild(col);
		            counter++;
		        }

		        Parent.appendChild(row);
		    }
		    winningPatterns();
		}

		//Computer Turn. Creates O icon and places it to the column according to the ComputerSequence.
		function computerTurn(column){
			document.getElementById("player-icon").style.visibility = "hidden";
			document.getElementById("computer-icon").style.visibility = "visible";
			var o_icon = document.createElement("div");
			o_icon.className = "o_icon";

			if(column != null){
				moves +=1;
				column.appendChild(o_icon);
				icon.colorize(o_icon, currentenv.user.colorvalue);
				player2Selections.push(parseInt(column.id));
				player2Selections.sort(function(a, b) { return a - b });
				gameBoard[column.id] = 2;

				computerSequence.splice(computerSequence.indexOf(parseInt(column.id)), 1);
			}
			else
			{
				return;
			}

		}

		//Player's Turn. Creates X icon when column is pressed.
		function playerTurn(column) {

			var x_icon = document.createElement("div");
			x_icon.className = "x_icon";

			moves +=1;
			column.appendChild(x_icon);

			icon.colorize(x_icon, currentenv.user.colorvalue);
			player1Selections.push(parseInt(column.id));
			player1Selections.sort(function(a, b) { return a - b });
			gameBoard[column.id] = 1;

			computerSequence.splice(computerSequence.indexOf(parseInt(column.id)), 1);

		}

		//List of possible winning patterns
		function winningPatterns(){
		    winners.push([0, 1, 2]);
		    winners.push([3, 4, 5]);
		    winners.push([6, 7, 8]);
		    winners.push([0, 3, 6]);
		    winners.push([1, 4, 7]);
		    winners.push([2, 5, 8]);
		    winners.push([0, 4, 8]);
		    winners.push([2, 4, 6]);
		}

		//Detects if a pattern is made
		function checkWinner() {
				// check if current player has a winning hand
				// only start checking when player x has size number of selections
				var win = false;
				var playerSelections = new Array();

				if (currentPlayer == 0)
					 playerSelections = player1Selections;
				else {
					playerSelections = player2Selections;
				}


				if (playerSelections.length >= size) {
						// check if any 'winners' are also in your selections

						for (i = 0; i < winners.length; i++) {
								var sets = winners[i];  // winning hand
								var setFound = true;

								for (r = 0; r < sets.length; r++) {
										// check if number is in current players hand
										// if not, break, not winner
										var found = false;

										// players hand
										for (s = 0; s < playerSelections.length; s++) {
												if (sets[r] == playerSelections[s]) {
														found = true;
														break;
												}
										}

										// value not found in players hand
										// not a valid set, move on
										if (found == false) {
												setFound = false;
												break;
										}
								}

								if (setFound == true) {
										win = true;
										break;
								}
						}
				}

				return win;
		}

		//Announces Winner or Draw.
		function announceWinner(){
			var isWin = checkWinner();
			console.log(isWin);
			//Winners are identified when XXX or OOO pattern is made
			//If no pattern is made at the end of the game, it results to a tie.
			if (isWin)
			{
				if(currentPlayer == 0){
					document.getElementById("mainBoard").style.display = "none";
					document.getElementById("player-icon").style.display = "none";
					document.getElementById("computer-icon").style.display = "none";
					document.getElementById("announceWin").innerHTML = "<h1>"+webL10n.get("Win", {name:currentenv.user.name})+ "</h1>";
				}
				else if (currentPlayer == 1){
					document.getElementById("mainBoard").style.display = "none";
					document.getElementById("player-icon").style.display = "none";
					document.getElementById("computer-icon").style.display = "none";
					document.getElementById("announceWin").innerHTML = "<h1>"+webL10n.get("Win", {name:"Computer"})+ "</h1>";
				}
			}

			else if(moves == 9)
			{
				document.getElementById("mainBoard").style.display = "none";
				document.getElementById("player-icon").style.display = "none";
				document.getElementById("computer-icon").style.display = "none";
				document.getElementById("announceWin").innerHTML = "<h1>"+webL10n.get("Draw") + "</h1>";
			}
		}


		//Save Tic Tac Toe to Journal
		function gotoDatastore() {
			console.log("writing...");
			var jsonData = JSON.stringify(gameBoard);
			activity.getDatastoreObject().setDataAsText(jsonData);
			activity.getDatastoreObject().save(function (error) {
				if (error === null) {
					console.log("write done.");
					console.log(gameBoard);
				} else {
					console.log("write failed.");
				}
			});
		}
		document.getElementById("stop-button").addEventListener('click', function (event) {
			gotoDatastore();
		});

		//New Game
		document.getElementById("new-game-button").addEventListener('click', function(event){
			gameBoard = [null, null, null, null, null, null, null, null, null];
			gotoDatastore();
			window.location.reload();
		});

		window.onload = drawBoard();
	});

});
